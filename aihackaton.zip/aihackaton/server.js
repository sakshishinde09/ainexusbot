
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));  // To serve static files like HTML, CSS, JS

// Home route
app.get('/', (req, res) => {
    res.send('Welcome to the Healthcare Website');
});

// Contact form submission endpoint
app.post('/contact', (req, res) => {
    const { name, email, message } = req.body;
    console.log('Received message:', name, email, message);
    
    // Here you can add code to send email or store the message in a database

    res.json({ status: 'Message received' });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
