// script.js
document.getElementById('send-btn').addEventListener('click', sendMessage);

function sendMessage() {
  const userInput = document.getElementById('user-input').value.trim();
  if (userInput !== '') {
    appendMessage(userInput, 'user');
    fetch('https://dyandasakshi.cognitiveservices.azure.com/language/:query-knowledgebases?projectName=DyandaSakshichatbot&api-version=2021-10-01&deploymentName=production', {
      method: 'POST',
      headers: {
        'Ocp-Apim-Subscription-Key': 'BIDLpE7bwkvkgeiAxf4WMqHn32Sp9LTcaAx07cwM7AVjgXq47s8UJQQJ99BAAC5T7U2XJ3w3AAAaACOGpZOK'
        ,'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: userInput })
    })
      .then(response => response.json())
      .then(data => appendMessage(data.reply, 'bot'));
  }
  document.getElementById('user-input').value = '';
}

function appendMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message', `${sender}-message`);
  messageDiv.textContent = message;
  document.getElementById('chat-box').appendChild(messageDiv);
  document.getElementById('chat-box').scrollTop = document.getElementById('chat-box').scrollHeight;
}
