language_key ="BIDLpE7bwkvkgeiAxf4WMqHn32Sp9LTcaAx07cwM7AVjgXq47s8UJQQJ99BAAC5T7U2XJ3w3AAAaACOGpZOK"
language_endpoint = "https://dyandasakshi.cognitiveservices.azure.com/"

from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential

def authenticate_client():
    ta_credential=AzureKeyCredential(language_key)
    ta_client=TextAnalyticsClient(
        endpoint=language_endpoint,
        crendential=ta_credential
    )
    return ta_client
client=authenticate_client()

