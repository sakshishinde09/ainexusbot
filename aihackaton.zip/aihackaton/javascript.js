document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    fetch('/contact', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, message })
    })
    .then(response => response.json())
    .then(data => alert('Message sent successfully!'))
    .catch(error => console.error('Error:', error));
});
function openChatbot() {
    document.getElementById('chatbot-container').style.display = 'block';
}

function closeChatbot() {
    document.getElementById('chatbot-container').style.display = 'none';
}

function sendMessage() {
    const userMessage = document.getElementById('user-input').value;
    if (userMessage.trim() === '') return;

    const messagesContainer = document.getElementById('chatbot-messages');

    // Display user message
    const userMessageElement = document.createElement('div');
    userMessageElement.textContent = 'You: ' + userMessage;
    userMessageElement.style.marginBottom = '10px';
    messagesContainer.appendChild(userMessageElement);

    // Display bot response (simple static response for now)
    const botResponse = 'Bot: I am your healthcare assistant. How can I help you today?';
    const botResponseElement = document.createElement('div');
    botResponseElement.textContent = botResponse;
    botResponseElement.style.marginBottom = '10px';
    messagesContainer.appendChild(botResponseElement);

    // Scroll to bottom of messages
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    // Clear input field
    document.getElementById('user-input').value = '';
}
