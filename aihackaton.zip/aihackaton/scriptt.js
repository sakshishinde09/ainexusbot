// Function to handle sending a message
function sendMessage() {
    const userInput = document.getElementById("user-input").value;

    if (userInput.trim() !== "") {
        // Display the user's message
        const userMessage = document.createElement("div");
        userMessage.classList.add("chatbot-message", "user-message");
        userMessage.innerHTML = `<p>${userInput}</p>`;
        document.getElementById("chatbot-body").appendChild(userMessage);

        // Clear input field
        document.getElementById("user-input").value = "";

        // Scroll to the bottom of the chat
        const chatbotBody = document.getElementById("chatbot-body");
        chatbotBody.scrollTop = chatbotBody.scrollHeight;

        // Simulate a bot response after a short delay
        setTimeout(() => {
            const botMessage = document.createElement("div");
            botMessage.classList.add("chatbot-message", "bot-message");
            botMessage.innerHTML = `<p>Sorry, I don't understand that yet!</p>`;
            document.getElementById("chatbot-body").appendChild(botMessage);

            // Scroll to the bottom again after bot response
            chatbotBody.scrollTop = chatbotBody.scrollHeight;
        }, 1000);
    }
}

// Function to close the chatbot
function closeChatbot() {
    const chatbotContainer = document.querySelector(".chatbot-container");
    chatbotContainer.style.display = "none";
}
